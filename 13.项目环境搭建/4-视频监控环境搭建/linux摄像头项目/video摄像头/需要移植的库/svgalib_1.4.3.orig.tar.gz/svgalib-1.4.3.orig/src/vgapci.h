extern int __svgalib_pci_find_vendor_vga(unsigned int vendor, unsigned long *conf, int cont);
extern int __svgalib_use_procpci, __svgalib_pci_ibus, __svgalib_pci_idev;
