#define SOLID
#define WRAP
#include "triangl.c"
